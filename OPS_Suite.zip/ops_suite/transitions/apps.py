from django.apps import AppConfig


class TransitionsConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "ops_suite.transitions"
    label = "transitions"
    verbose_name = "Transition Management"
